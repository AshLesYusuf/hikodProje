document.querySelectorAll('.accordion-button').forEach(button => {
    button.addEventListener('click', function () {
      const target = document.querySelector(this.dataset.bsTarget);
      
      // Eğer açık ise kapat
      if (target.classList.contains('show')) {
        const collapse = bootstrap.Collapse.getInstance(target);
        collapse.hide();
      } else {
        // Değilse normal davranış
        const collapse = new bootstrap.Collapse(target, {
          toggle: true
        });
      }
    });
  });