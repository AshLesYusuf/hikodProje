document.addEventListener('DOMContentLoaded', function() {
    console.log("Accordion.js yüklendi");
    
    // Butonları ve dropdownları al
    const signInBtn = document.getElementById('signInBtn');
    const registerBtn = document.getElementById('registerBtn');
    const loginDropdown = document.getElementById('loginDropdown');
    const registerDropdown = document.getElementById('registerDropdown');
    
    console.log("Login Button:", signInBtn);
    console.log("Register Button:", registerBtn);
    console.log("Login Dropdown:", loginDropdown);
    console.log("Register Dropdown:", registerDropdown);
    
    // Giriş Yap butonuna tıklama
    if (signInBtn) {
        signInBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log("Giriş Yap butonuna tıklandı");
            
            // Dropdown menüyü aç/kapat
            if (loginDropdown.style.display === 'block') {
                loginDropdown.style.display = 'none';
                console.log("Login dropdown kapatıldı");
            } else {
                loginDropdown.style.display = 'block';
                console.log("Login dropdown açıldı");
                
                // Diğer dropdown'ı kapat
                if (registerDropdown) {
                    registerDropdown.style.display = 'none';
                }
            }
        });
    }
    
    // Kayıt Ol butonuna tıklama
    if (registerBtn) {
        registerBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log("Kayıt Ol butonuna tıklandı");
            
            // Dropdown menüyü aç/kapat
            if (registerDropdown.style.display === 'block') {
                registerDropdown.style.display = 'none';
                console.log("Register dropdown kapatıldı");
            } else {
                registerDropdown.style.display = 'block';
                console.log("Register dropdown açıldı");
                
                // Diğer dropdown'ı kapat
                if (loginDropdown) {
                    loginDropdown.style.display = 'none';
                }
            }
        });
    }
    
    // Sayfa dışına tıklandığında dropdown'ları kapat
    document.addEventListener('click', function(e) {
        if (signInBtn && loginDropdown) {
            if (!signInBtn.contains(e.target) && !loginDropdown.contains(e.target)) {
                loginDropdown.style.display = 'none';
            }
        }
        
        if (registerBtn && registerDropdown) {
            if (!registerBtn.contains(e.target) && !registerDropdown.contains(e.target)) {
                registerDropdown.style.display = 'none';
            }
        }
    });
    
    // Şifre göster/gizle
    const passwordToggles = document.querySelectorAll('.password-toggle');
    
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordInput = this.parentNode.querySelector('.password-input');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            // İkonu değiştir
            this.classList.toggle('bx-hide');
            this.classList.toggle('bx-show');
        });
    });
}); 