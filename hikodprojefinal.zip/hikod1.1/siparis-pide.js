// Sayfa yüklendiğinde her ürünün fiyatını göster
window.onload = () => {
    document.querySelectorAll('.product-container').forEach((urunDiv) => {
      const birimFiyat = parseInt(urunDiv.getAttribute('data-fiyat'));
      urunDiv.querySelector('.price').textContent = `${birimFiyat} TL`;
    });
    
    // Sepet sayısını güncelle
    updateCartCount();
  };
  
  // Ortak fonksiyon: artı / eksi değişikliği
  function updateQuantity(btn, change) {
    const wrapper = btn.closest('.product-container');
    const numberSpan = wrapper.querySelector('.number');
    const priceSpan = wrapper.querySelector('.price');
    const birimFiyat = parseInt(wrapper.getAttribute('data-fiyat'));
  
    let number = parseInt(numberSpan.innerText) + change;
    number = number < 0 ? 0 : number;
    numberSpan.innerText = number;
  
    const totalPrice = number * birimFiyat;
    priceSpan.innerText = `${totalPrice} TL`;
  }
  
  function increase(btn) {
    updateQuantity(btn, 1);
  }
  
  function decrease(btn) {
    updateQuantity(btn, -1);
  }
  
  // Sepete Ekleme Fonksiyonu
  function sepeteEkle(btn) {
    const wrapper = btn.closest('.product-container');
    const urunAdi = wrapper.querySelector('h4').innerText;
    const adet = parseInt(wrapper.querySelector('.number').innerText);
    const birimFiyat = parseInt(wrapper.getAttribute('data-fiyat'));
    const totalFiyat = adet * birimFiyat;
    
    // Sepete eklemek için adet kontrolü
    if (adet <= 0) {
      alert('Lütfen en az 1 adet ürün seçiniz!');
      return;
    }
    
    // LocalStorage'dan mevcut sepeti al
    let sepet = JSON.parse(localStorage.getItem('sepet')) || [];
    
    // Ürün zaten sepette var mı kontrol et
    const existingItemIndex = sepet.findIndex(item => item.urunAdi === urunAdi);
    
    if (existingItemIndex !== -1) {
      // Varsa miktarını güncelle
      sepet[existingItemIndex].adet += adet;
      sepet[existingItemIndex].totalFiyat = sepet[existingItemIndex].adet * sepet[existingItemIndex].birimFiyat;
    } else {
      // Yoksa yeni ürün olarak ekle
      sepet.push({
        urunAdi,
        adet,
        birimFiyat,
        totalFiyat
      });
    }
    
    // Sepeti localStorage'a kaydet
    localStorage.setItem('sepet', JSON.stringify(sepet));
    
    // Ürün sayacını resetle
    wrapper.querySelector('.number').innerText = "0";
    wrapper.querySelector('.price').innerText = `${birimFiyat} TL`;
    
    // Bildirim göster
    alert(`"${urunAdi}" sepete eklendi! (${adet} adet)`);
    
    // Sepet sayısını güncelle
    updateCartCount();
  }
  
  // Sepetteki toplam ürün sayısını güncelleme
  function updateCartCount() {
    const sepet = JSON.parse(localStorage.getItem('sepet')) || [];
    const toplamAdet = sepet.reduce((toplam, item) => toplam + item.adet, 0);
    
    // Eğer sayfada bir sepet sayaç elementi varsa güncelle
    const sepetSayac = document.querySelector('.cart-count');
    if (sepetSayac) {
      sepetSayac.innerText = toplamAdet;
      sepetSayac.style.display = toplamAdet > 0 ? 'block' : 'none';
    }
  }
  
  
  