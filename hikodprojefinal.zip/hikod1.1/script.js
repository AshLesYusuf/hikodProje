// This is your original script file
// You can add your JavaScript code here

document.addEventListener('DOMContentLoaded', function() {
    // Header elementleri
    /* Aşağıdaki dropdown kodlarını devre dışı bırakıyorum çünkü bu işlevler accordion.js'de tanımlanmış
    const signInBtn = document.getElementById('signInBtn');
    const registerBtn = document.getElementById('registerBtn');
    const loginDropdown = document.getElementById('loginDropdown');
    const registerDropdown = document.getElementById('registerDropdown');
    */
    
    const mobileToggle = document.querySelector('.mobile-toggle');
    const header = document.querySelector('.modern-header');
    
    // Menü Linkleri
    const menuLinks = document.querySelectorAll('a[href^="#"]');
    
    // LocalStorage ile kullanıcı yönetimi
    let users = JSON.parse(localStorage.getItem('users')) || [];
    let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
    
    // Kullanıcı oturum durumu kontrolü
    checkUserSession();
    
    // Sayfa içi linklerin scroll davranışı
    menuLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Mobil menüyü kapat
            header.classList.remove('mobile-menu-active');
            
            const targetId = this.getAttribute('href');
            if(targetId !== '#') {
                const targetElement = document.querySelector(targetId);
                if(targetElement) {
                    const headerHeight = header.offsetHeight;
                    const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - headerHeight;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // Mobil menü toggle
    if(mobileToggle) {
        mobileToggle.addEventListener('click', function() {
            header.classList.toggle('mobile-menu-active');
        });
    }
    
    // Sayfada herhangi bir yere tıklayınca mobil menüyü kapat
    document.addEventListener('click', function(e) {
        if(header.classList.contains('mobile-menu-active') && 
           !e.target.closest('.header-container')) {
            header.classList.remove('mobile-menu-active');
        }
        
        /* Bu kısımları devre dışı bırakıyorum çünkü accordion.js ile çakışıyor
        // Dropdown formların dışına tıklandığında kapatma
        if (loginDropdown.style.display === 'block' && 
            !e.target.closest('#loginDropdown') && 
            e.target !== signInBtn && 
            !e.target.closest('#signInBtn')) {
            loginDropdown.style.display = 'none';
        }
        
        if (registerDropdown.style.display === 'block' && 
            !e.target.closest('#registerDropdown') && 
            e.target !== registerBtn && 
            !e.target.closest('#registerBtn')) {
            registerDropdown.style.display = 'none';
        }
        */
    });
    
    /* Bu kısımları devre dışı bırakıyorum çünkü accordion.js ile çakışıyor
    // Giriş butonunu tıklama
    if(signInBtn) {
        signInBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Mobil menü açıksa kapat
            header.classList.remove('mobile-menu-active');
            
            // Kullanıcı giriş yapmışsa, çıkış yap
            if(currentUser) {
                logout();
                return;
            }
            
            // Login formunu göster
            toggleDropdown('login');
        });
    }
    
    // Kayıt butonunu tıklama
    if(registerBtn) {
        registerBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Mobil menü açıksa kapat
            header.classList.remove('mobile-menu-active');
            
            // Kullanıcı giriş yapmışsa işlem yapma
            if(currentUser) return;
            
            // Register formunu göster
            toggleDropdown('register');
        });
    }
    
    // Dropdown göster/gizle fonksiyonu
    function toggleDropdown(formType) {
        if (formType === 'login') {
            // Diğer dropdown'ı kapat
            registerDropdown.style.display = 'none';
            
            // Login dropdown'ını göster/gizle
            if (loginDropdown.style.display === 'block') {
                loginDropdown.style.display = 'none';
            } else {
                loginDropdown.style.display = 'block';
            }
        } else {
            // Diğer dropdown'ı kapat
            loginDropdown.style.display = 'none';
            
            // Register dropdown'ını göster/gizle
            if (registerDropdown.style.display === 'block') {
                registerDropdown.style.display = 'none';
            } else {
                registerDropdown.style.display = 'block';
            }
        }
    }
    
    // Şifre görünürlük toggle
    const passwordToggles = document.querySelectorAll('.password-toggle');
    
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordField = this.closest('.password-field').querySelector('.password-input');
            
            if(passwordField.type === 'password') {
                passwordField.type = 'text';
                this.classList.remove('bx-hide');
                this.classList.add('bx-show');
            } else {
                passwordField.type = 'password';
                this.classList.remove('bx-show');
                this.classList.add('bx-hide');
            }
        });
    });
    */
    
    /* Bu kısımları da devre dışı bırakıyorum çünkü yakın işlevsellikleri içeren kodlar accordion.js'de var
    // Giriş formu gönderimi
    const loginButton = document.getElementById('loginButton');
    if(loginButton) {
        loginButton.addEventListener('click', function() {
            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value.trim();
            
            if(login(email, password)) {
                showSuccessAnimation(this, "Giriş Başarılı!");
                setTimeout(() => {
                    resetForm(loginDropdown.querySelector('.login-dropdown-form'));
                    loginDropdown.style.display = 'none';
                }, 1000);
            } else {
                showFormError(loginDropdown.querySelector('.login-dropdown-form'));
            }
        });
    }
    
    // Kayıt formu gönderimi
    const registerButton = document.getElementById('registerButton');
    if(registerButton) {
        registerButton.addEventListener('click', function() {
            const name = document.getElementById('registerName').value.trim();
            const email = document.getElementById('registerEmail').value.trim();
            const password = document.getElementById('registerPassword').value.trim();
            const confirmPassword = document.getElementById('confirmPassword').value.trim();
            
            if(register(name, email, password, confirmPassword)) {
                showSuccessAnimation(this, "Kayıt Başarılı!");
                setTimeout(() => {
                    resetForm(registerDropdown.querySelector('.login-dropdown-form'));
                    registerDropdown.style.display = 'none';
                }, 1000);
            } else {
                showFormError(registerDropdown.querySelector('.login-dropdown-form'));
            }
        });
    }
    
    // Şifremi unuttum linki
    const forgotPassword = document.querySelector('.forgot-password a');
    if(forgotPassword) {
        forgotPassword.addEventListener('click', function(e) {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value.trim();
            
            if(email) {
                alert(`"${email}" adresine şifre sıfırlama bağlantısı gönderildi.`);
            } else {
                alert("Lütfen önce e-posta adresinizi girin.");
                document.getElementById('loginEmail').focus();
            }
        });
    }
    */
    
    // Kullanıcı kayıt fonksiyonu
    function register(name, email, password, confirmPassword) {
        // Form validasyonu
        if(!name || !email || !password || !confirmPassword) {
            showValidationErrors(['registerName', 'registerEmail', 'registerPassword', 'confirmPassword']);
            return false;
        }
        
        // Şifre uzunluğu kontrolü
        if(password.length < 6) {
            alert("Şifre en az 6 karakter olmalıdır.");
            highlightField('registerPassword');
            return false;
        }
        
        // Şifrelerin eşleşmesini kontrol
        if(password !== confirmPassword) {
            alert("Şifreler eşleşmiyor.");
            highlightField('confirmPassword');
            return false;
        }
        
        // E-posta formatını kontrol
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(!emailRegex.test(email)) {
            alert("Geçerli bir e-posta adresi girin.");
            highlightField('registerEmail');
            return false;
        }
        
        // E-postanın var olup olmadığını kontrol
        if(users.some(user => user.email === email)) {
            alert("Bu e-posta adresi zaten kayıtlı.");
            highlightField('registerEmail');
            return false;
        }
        
        // Yeni kullanıcı oluştur
        const newUser = {
            id: Date.now(),
            name,
            email,
            password
        };
        
        // Kullanıcıları güncelle
        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));
        
        return true;
    }
    
    // Kullanıcı giriş fonksiyonu
    function login(email, password) {
        // Form validasyonu
        if(!email || !password) {
            showValidationErrors(['loginEmail', 'loginPassword']);
            return false;
        }
        
        // Kullanıcıyı bul
        const user = users.find(user => user.email === email && user.password === password);
        
        if(!user) {
            alert("E-posta veya şifre hatalı.");
            return false;
        }
        
        // Kullanıcı bilgilerini sakla
        localStorage.setItem('currentUser', JSON.stringify({
            id: user.id,
            name: user.name,
            email: user.email
        }));
        
        // Aktif kullanıcıyı güncelle
        currentUser = {
            id: user.id,
            name: user.name,
            email: user.email
        };
        
        // UI güncelle
        updateUIForLoggedInUser();
        
        return true;
    }
    
    // Çıkış fonksiyonu
    function logout() {
        localStorage.removeItem('currentUser');
        currentUser = null;
        updateUIForLoggedOutUser();
        alert("Çıkış yapıldı.");
    }
    
    // Kullanıcı oturum durumu kontrolü
    function checkUserSession() {
        if(currentUser) {
            updateUIForLoggedInUser();
        } else {
            updateUIForLoggedOutUser();
        }
    }
    
    // Giriş yapıldığında UI güncelleme
    function updateUIForLoggedInUser() {
        const signInBtn = document.getElementById('signInBtn');
        const registerBtn = document.getElementById('registerBtn');
        const loginDropdown = document.getElementById('loginDropdown');
        const registerDropdown = document.getElementById('registerDropdown');
        
        if(signInBtn) {
            signInBtn.innerHTML = `<i class='bx bx-user-circle'></i><span>${currentUser.name}</span>`;
        }
        
        if(registerBtn) {
            registerBtn.innerHTML = `<span>Çıkış Yap</span>`;
        }
        
        // Formları gizle
        if(loginDropdown) loginDropdown.style.display = 'none';
        if(registerDropdown) registerDropdown.style.display = 'none';
    }
    
    // Çıkış yapıldığında UI güncelleme
    function updateUIForLoggedOutUser() {
        const signInBtn = document.getElementById('signInBtn');
        const registerBtn = document.getElementById('registerBtn');
        const loginDropdown = document.getElementById('loginDropdown');
        const registerDropdown = document.getElementById('registerDropdown');
        
        if(signInBtn) {
            signInBtn.innerHTML = `<i class='bx bx-user-circle'></i><span>Giriş Yap</span>`;
        }
        
        if(registerBtn) {
            registerBtn.innerHTML = `<span>Kayıt Ol</span>`;
        }
        
        // Formları gizle
        if(loginDropdown) loginDropdown.style.display = 'none';
        if(registerDropdown) registerDropdown.style.display = 'none';
    }
    
    // Hata animasyonu göster
    function showFormError(form) {
        form.classList.add('form-error-shake');
        setTimeout(() => {
            form.classList.remove('form-error-shake');
        }, 600);
    }
    
    // Form alanlarını temizle
    function resetForm(formContainer) {
        const inputs = formContainer.querySelectorAll('.form-input');
        inputs.forEach(input => {
            input.value = '';
            input.classList.remove('error');
        });
    }
    
    // Hatalı alanları vurgula
    function showValidationErrors(fieldIds) {
        fieldIds.forEach(id => {
            const field = document.getElementById(id);
            if(field && !field.value.trim()) {
                field.classList.add('error');
            }
        });
    }
    
    // Alanı vurgula
    function highlightField(fieldId) {
        const field = document.getElementById(fieldId);
        if(field) {
            field.classList.add('error');
            field.focus();
        }
    }
    
    // Başarı animasyonu göster
    function showSuccessAnimation(button, message) {
        button.textContent = message;
        button.classList.add('btn-success');
        setTimeout(() => {
            button.classList.remove('btn-success');
        }, 1000);
    }
});

// Sepete ürün eklendiğinde kontrol et
function checkFloatingCartBtn() {
    const sepet = JSON.parse(localStorage.getItem('sepet')) || [];
    const cartBtn = document.getElementById('floatingCartBtn');
    const hoverBox = document.getElementById('cartHoverSummary');

    if (sepet.length > 0) {
        cartBtn.style.display = 'flex';

        // Özet içeriği hazırla
        hoverBox.innerHTML = '';
        sepet.forEach(item => {
            hoverBox.innerHTML += `
                <div style="margin-bottom: 5px;">
                    <strong>${item.urunAdi}</strong><br>
                    ${item.adet} x ${item.birimFiyat} TL = ${item.totalFiyat} TL
                </div>
            `;
        });
    } else {
        cartBtn.style.display = 'none';
    }
}


function sepeteEkle(btn) {
    const wrapper = btn.closest('.product-container');
    const urunAdi = wrapper.querySelector('h4').innerText;
    const adet = parseInt(wrapper.querySelector('.number').innerText);
    const birimFiyat = parseInt(wrapper.getAttribute('data-fiyat'));
    const totalFiyat = adet * birimFiyat;
  
    if (adet <= 0) {
      alert('Lütfen en az 1 adet ürün seçiniz!');
      return;
    }
  
    let sepet = JSON.parse(localStorage.getItem('sepet')) || [];
  
    const existingItemIndex = sepet.findIndex(item => item.urunAdi === urunAdi);
  
    if (existingItemIndex !== -1) {
      sepet[existingItemIndex].adet += adet;
      sepet[existingItemIndex].totalFiyat = sepet[existingItemIndex].adet * sepet[existingItemIndex].birimFiyat;
    } else {
      sepet.push({
        urunAdi,
        adet,
        birimFiyat,
        totalFiyat
      });
    }
  
    localStorage.setItem('sepet', JSON.stringify(sepet));
  
    wrapper.querySelector('.number').innerText = "0";
    wrapper.querySelector('.price').innerText = `${birimFiyat} TL`;
  
    alert(`"${urunAdi}" sepete eklendi! (${adet} adet)`);
  
    updateCartCount();
    checkFloatingCartBtn(); // butonu güncel tut
  }
  
